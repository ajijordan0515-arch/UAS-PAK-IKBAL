<?php 
include 'koneksi.php';
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="shortcut icon" href="./assets/img/building-store.png" type="image/x-icon">
    <title>Login</title>

    <!-- Bootstrap & Tabler CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="./assets/css/tabler.min.css" rel="stylesheet" />

    <!-- Background Animation -->
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            background: url('https://www.transparenttextures.com/patterns/stardust.png'), linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            background-size: cover;
            animation: moveBackground 30s linear infinite;
        }

        @keyframes moveBackground {
            0% { background-position: 0 0, 0 0; }
            100% { background-position: 1000px 0, 0 0; }
        }

        .card {
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        }
    </style>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
</head>

<body class="d-flex justify-content-center align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="text-center mb-4 text-white">
                    <h2><img src="./assets/img/building-store.svg" height="36" alt=""> PHP-KASIR</h2>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">Masuk ke akun Anda</h2>
                        <form action="" method="POST">
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Kata Sandi</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                            <div class="form-footer">
                                <button class="btn btn-primary w-100" type="submit" name="login">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-login" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                        <path d="M14 8v-2a2 2 0 0 0 -2 -2h-7a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2 -2v-2"></path>
                                        <path d="M20 12h-13l3 -3m0 6l-3 -3"></path>
                                    </svg>
                                    Login
                                </button>
                            </div>
                        </form>
                        <?php if (isset($_GET['status']) && $_GET['status'] == 'success') : ?>
                            <div class="alert alert-success mt-3">Login berhasil!</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/js/tabler.min.js" defer></script>
</body>

</html>

<?php
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = sha1($_POST['password']);

    $ambil = $koneksi->query("SELECT * FROM user WHERE email_user='$email' AND password_user='$password'");
    $cekuser = $ambil->fetch_assoc();

    if (empty($cekuser)) {
        echo "<script>alert('Login gagal!'); location='index.php';</script>";
    } else {
        $_SESSION['user'] = $cekuser;
        $redirect = $cekuser['level_user'] === 'kasir' ? 'kasir/index.php' : 'gudang/index.php';
        echo "<script>location='{$redirect}?status=success'</script>";
    }
}
?>
