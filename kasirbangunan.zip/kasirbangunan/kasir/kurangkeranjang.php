<?php
session_start();
include '../koneksi.php';

$id_produk = isset($_POST['id_produk']) ? intval($_POST['id_produk']) : 0;

// Pastikan produk ada dalam keranjang
if (isset($_SESSION['keranjang'][$id_produk])) {
    // Jika jumlah produk = 1, maka hapus dari keranjang
    if ($_SESSION['keranjang'][$id_produk] <= 1) {
        unset($_SESSION['keranjang'][$id_produk]);
    } else {
        // Kurangi jumlah produk
        $_SESSION['keranjang'][$id_produk] -= 1;
    }
}

// Anda bisa tambahkan respon JSON jika ini dipanggil via AJAX
// echo json_encode(['status' => 'ok']);
?>
