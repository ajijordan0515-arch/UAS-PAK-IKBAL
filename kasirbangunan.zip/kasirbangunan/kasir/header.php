<?php
include '../koneksi.php';

if (!isset($_SESSION['user'])) {
    echo "<script>alert('Anda harus login!')</script>";
    echo "<script>location='../index.php'</script>";
    exit();
}

$skrg = $_SERVER['REQUEST_URI'];
$subtitle = "Dashboard";

if ($skrg == "/kasir/index.php") {
    $subtitle = "Dashboard";
} elseif ($skrg == "/kasir/penjualan.php") {
    $subtitle = "Penjualan";
} elseif ($skrg == "/kasir/laporan.php") {
    $subtitle = "Laporan";
} elseif ($skrg == "/kasir/akun.php") {
    $subtitle = "Akun";
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="shortcut icon" href="../assets/img/building-store.png" type="image/x-icon">
    <title>Kasir</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/tabler.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f6f9fc, #e9eff5);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-brand svg {
            color: #2c3e50;
        }
        .navbar-light {
            background-color: #ffffff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        .nav-link.active {
            font-weight: bold;
            color: #0d6efd !important;
            background-color: #e7f1ff;
            border-radius: 0.375rem;
        }
        .page-header {
            padding: 1.5rem 0;
        }
    </style>
</head>

<body>
    <div class="page">
        <header class="navbar navbar-expand-md navbar-light d-print-none">
            <div class="container-xl">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <h1 class="navbar-brand navbar-brand-autodark d-none-navbar-horizontal pe-0 pe-md-3">
                    <a href="index.php" class="text-decoration-none">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-building-store" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                            <line x1="3" y1="21" x2="21" y2="21"></line>
                            <path d="M3 7v1a3 3 0 0 0 6 0v-1m0 1a3 3 0 0 0 6 0v-1m0 1a3 3 0 0 0 6 0v-1h-18l2 -4h14l2 4"></path>
                            <line x1="5" y1="21" x2="5" y2="10.85"></line>
                            <line x1="19" y1="21" x2="19" y2="10.85"></line>
                            <path d="M9 21v-4a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v4"></path>
                        </svg> KASIR
                    </a>
                </h1>
                <div class="navbar-nav flex-row order-md-last">
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown" aria-label="Open user menu">
                            <span class="avatar avatar-sm" style="background-image: url(https://placekitten.com/200/300)"></span>
                            <div class="d-none d-xl-block ps-2">
                                <div><?= $_SESSION['user']['nama_user']; ?></div>
                                <div class="mt-1 small text-muted"><?= $_SESSION['user']['level_user']; ?></div>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                            <a href="akun.php" class="dropdown-item <?= ($skrg == '/kasir/akun.php') ? 'active' : ''; ?>">Akun</a>
                            <div class="dropdown-divider"></div>
                            <a href="logout.php" class="dropdown-item">Logout</a>
                        </div>
                    </div>
                </div>
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <div class="d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center">
                        <ul class="navbar-nav">
                            <li class="nav-item <?= ($skrg == '/kasir/index.php') ? 'active' : ''; ?>">
                                <a class="nav-link" href="index.php">
                                    <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="bi bi-house"></i></span>
                                    <span class="nav-link-title">Home</span>
                                </a>
                            </li>
                            <li class="nav-item <?= ($skrg == '/kasir/penjualan.php') ? 'active' : ''; ?>">
                                <a class="nav-link" href="penjualan.php">
                                    <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="bi bi-bag"></i></span>
                                    <span class="nav-link-title">Penjualan</span>
                                </a>
                            </li>
                            <li class="nav-item <?= ($skrg == '/kasir/laporan.php') ? 'active' : ''; ?>">
                                <a class="nav-link" href="laporan.php">
                                    <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="bi bi-file-earmark-text"></i></span>
                                    <span class="nav-link-title">Laporan</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <div class="page-wrapper">
            <div class="container-xl">
                <div class="page-header d-print-none">
                    <div class="row g-2 align-items-center">
                        <div class="col">
                            <div class="page-pretitle">Halaman</div>
                            <h2 class="page-title"><?= $subtitle; ?></h2>
                        </div>
                    </div>
                </div>
