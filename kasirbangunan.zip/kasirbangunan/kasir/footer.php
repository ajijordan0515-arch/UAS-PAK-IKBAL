<!-- Footer -->
<footer class="footer bg-white border-top shadow-sm text-muted d-print-none w-100 mt-auto">
  <div class="container-fluid px-4 py-3">
    <div class="row align-items-center justify-content-between">
      <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
        <span class="d-block d-md-inline">
          &copy; <?= date("Y"); ?> 
          <a href="#" class="text-decoration-none fw-bold text-primary">ganzz</a>. All rights reserved.
        </span>
      </div>
      <div class="col-md-6 text-center text-md-end">
        <span class="d-inline-flex align-items-center">
          <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-inline text-danger me-2" width="20" height="20" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none"/>
            <path d="M19.5 12.572l-7.5 7.428l-7.5 -7.428m0 0a5 5 0 1 1 7.5 -6.566a5 5 0 1 1 7.5 6.572" />
          </svg>
          <small class="text-muted">Dibuat dengan cinta oleh kami</small>
        </span>
      </div>
    </div>
  </div>
</footer>

<!-- Tambahan JS Tabler (jika digunakan) -->
<script src="../assets/js/tabler.min.js" defer></script>
</body>
</html>
