<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Keranjang Belanja</title>

  <!-- Bootstrap & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Custom Style -->
  <style>
 html, body {
  height: 100%;
  margin: 0;
  padding: 0;
}

body {
  display: flex;
  flex-direction: column;
  background: linear-gradient(to right, #e0eafc, #cfdef3);
  font-family: 'Segoe UI', sans-serif;
}

/* Konten utama */
.container,
.content {
  flex: 1 0 auto;
  padding-bottom: 20px;
}

/* Kartu produk */
.card {
  border-radius: 15px;
  box-shadow: 0 5px 15px rgba(0,0,0,0.1);
  transition: 0.3s;
}
.card:hover {
  transform: translateY(-3px);
}

/* Form pencarian */
.btn-cari i {
  margin-right: 6px;
}
.input-cari {
  border-radius: 8px 0 0 8px;
}
.btn-cari {
  border-radius: 0 8px 8px 0;
}
.icon-title {
  margin-right: 10px;
}

/* Footer responsif & penuh layar */
.footer {
  background: #ffffff;
  border-top: 1px solid #ddd;
  padding: 1rem 0;
  color: #6c757d;
  flex-shrink: 0;
  width: 100%;
  box-shadow: 0 -1px 5px rgba(0, 0, 0, 0.05);
}

</style>

  </style>
</head>

<body>
  <div class="container py-5">
    <div class="row g-4">
      <!-- Kolom Produk -->
      <div class="col-lg-9">
        <div class="card">
          <div class="card-body bg-white">
            <form method="post" class="mb-3">
              <div class="input-group">
                <input type="text" name="cari" class="form-control input-cari" placeholder="🔍 Cari produk...">
                <button class="btn btn-primary btn-cari">
                  <i class="bi bi-search"></i> Cari
                </button>
              </div>
            </form>
            <div class="list-produk"></div>
          </div>
        </div>
      </div>

      <!-- Kolom Keranjang -->
      <div class="col-lg-3">
        <div class="card border-success">
          <div class="card-header bg-success text-white">
            <h5 class="mb-0">
              <i class="bi bi-cart-fill icon-title"></i>Keranjang
            </h5>
          </div>
          <div class="card-body keranjang">
            <!-- AJAX akan isi -->
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Script Ajax -->
  <script>
    $(document).ready(function () {
      $.ajax({ url: 'listproduk.php', success: function (hasil) { $(".list-produk").html(hasil); } });
      $.ajax({ url: 'tampilkeranjang.php', success: function (hasil) { $(".keranjang").html(hasil); } });

      $(document).on("click", ".btn-cari", function (e) {
        e.preventDefault();
        var cari = $(".input-cari").val();
        $.ajax({
          type: 'post',
          url: 'cariproduk.php',
          data: 'cari=' + cari,
          success: function (hasil) {
            $(".list-produk").html(hasil);
          }
        });
      });

      $(document).on("click", ".link-produk", function () {
        var id_produk = $(this).attr("idnya");
        $.ajax({
          type: 'post',
          url: 'masukkankeranjang.php',
          data: 'id_produk=' + id_produk,
          success: function () {
            $.ajax({ url: 'tampilkeranjang.php', success: function (hasil) { $(".keranjang").html(hasil); } });
          }
        });
      });

      $(document).on("click", ".tambahi", function () {
        var id_produk = $(this).attr("idnya");
        $.ajax({
          type: 'post',
          url: 'tambahkeranjang.php',
          data: 'id_produk=' + id_produk,
          success: function () {
            $.ajax({ url: 'tampilkeranjang.php', success: function (hasil) { $(".keranjang").html(hasil); } });
          }
        });
      });

      $(document).on("click", ".kurangi", function () {
        var id_produk = $(this).attr("idnya");
        $.ajax({
          type: 'post',
          url: 'kurangkeranjang.php',
          data: 'id_produk=' + id_produk,
          success: function () {
            $.ajax({ url: 'tampilkeranjang.php', success: function (hasil) { $(".keranjang").html(hasil); } });
          }
        });
      });

      $(document).on("keyup", ".bayar", function () {
        var bayar = $(this).val();
        var total = $(".total").val();
        var kembalian = parseInt(bayar) - parseInt(total);
        $(".kembalian").val(kembalian);
      });
    });
  </script>
</body>
</html>

<?php include 'footer.php'; ?>
