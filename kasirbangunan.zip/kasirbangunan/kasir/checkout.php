<?php
session_start();
include '../koneksi.php';

// Validasi keranjang
if (!isset($_SESSION['keranjang']) || empty($_SESSION['keranjang'])) {
    $_SESSION['status'] = "Keranjang kosong!";
    $_SESSION['status_type'] = "error";
    echo "<script>location='penjualan_produk.php';</script>";
    exit;
}

// Ambil data dari form
$total = $_POST["total"];
$bayar = $_POST["bayar"];
$kembalian = $_POST["kembalian"];
$telepon = trim($_POST["telepon"]);
$tanggal = date("Y-m-d H:i:s");

$id_toko = $_SESSION['user']['id_toko'];
$id_user = $_SESSION['user']['id_user'];

// Validasi nilai
if ($bayar < $total) {
    $_SESSION['status'] = "Bayar tidak cukup!";
    $_SESSION['status_type'] = "error";
    echo "<script>location='penjualan_produk.php';</script>";
    exit;
}

// Penanganan pelanggan
if (empty($telepon)) {
    $id_pelanggan = NULL;
} else {
    $telepon = mysqli_real_escape_string($koneksi, $telepon);
    $ambil = $koneksi->query("SELECT * FROM pelanggan WHERE telepon_pelanggan='$telepon'");
    $pelanggan = $ambil->fetch_assoc();

    if (!$pelanggan) {
        $koneksi->query("INSERT INTO pelanggan (telepon_pelanggan) VALUES('$telepon')");
        $id_pelanggan = $koneksi->insert_id;
    } else {
        $id_pelanggan = $pelanggan['id_pelanggan'];
    }
}

// Simpan data ke tabel penjualan
$koneksi->query("INSERT INTO penjualan
    (id_pelanggan, id_toko, id_user, tanggal_penjualan, total_penjualan, bayar_penjualan, kembalian_penjualan)
    VALUES('$id_pelanggan', '$id_toko', '$id_user', '$tanggal', '$total', '$bayar', '$kembalian')");

$id_penjualan = $koneksi->insert_id;

// Proses setiap produk dalam keranjang
foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
    $id_produk = intval($id_produk);
    $jumlah = intval($jumlah);

    $ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk' AND id_toko='$id_toko'");
    $produk = $ambil->fetch_assoc();

    if (!$produk) continue;

    // Validasi stok
    if ($produk['stok_produk'] < $jumlah) {
        continue; // atau log error stok kurang
    }

    $harga_beli = $produk['beli_produk'];
    $harga_jual = $produk['jual_produk'];
    $nama_jual = $produk['nama_produk'];
    $subtotal_jual = $harga_jual * $jumlah;

    // Simpan detail penjualan
    $koneksi->query("INSERT INTO penjualan_produk
        (id_penjualan, id_toko, id_produk, harga_beli, harga_jual, nama_jual, subtotal_jual, jumlah_jual)
        VALUES('$id_penjualan', '$id_toko', '$id_produk', '$harga_beli', '$harga_jual', '$nama_jual', '$subtotal_jual', '$jumlah')");

    // Update stok produk
    $koneksi->query("UPDATE produk SET stok_produk = stok_produk - $jumlah WHERE id_produk = '$id_produk'");
}

// Bersihkan keranjang
unset($_SESSION['keranjang']);

// Notifikasi dan redirect
$_SESSION['status'] = "Transaksi pembelian berhasil!";
$_SESSION['status_type'] = "success";
echo "<script>location='penjualan_produk.php?id=$id_penjualan';</script>";
exit;
?>
