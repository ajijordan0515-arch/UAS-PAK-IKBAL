<?php
session_start();
include '../koneksi.php';

// Pastikan input valid
$id_produk = isset($_POST['id_produk']) ? intval($_POST['id_produk']) : 0;

// Validasi sesi user dan toko
if (!isset($_SESSION['user']['id_toko'])) {
    exit('Toko tidak ditemukan dalam sesi.');
}

$id_toko = $_SESSION['user']['id_toko'];

// Ambil data produk dari database
$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk' AND id_toko='$id_toko'");
$produk = $ambil->fetch_assoc();

// Pastikan produk ada dan stok tersedia
if ($produk && $produk['stok_produk'] > 0) {
    // Inisialisasi keranjang jika belum ada
    if (!isset($_SESSION['keranjang'])) {
        $_SESSION['keranjang'] = [];
    }

    // Jika produk belum ada di keranjang, masukkan dengan jumlah 1
    if (!isset($_SESSION['keranjang'][$id_produk])) {
        $_SESSION['keranjang'][$id_produk] = 1;
    } else {
        $jumlah_dikeranjang = $_SESSION['keranjang'][$id_produk];

        // Tambah jumlah hanya jika belum melebihi stok
        if ($produk['stok_produk'] > $jumlah_dikeranjang) {
            $_SESSION['keranjang'][$id_produk] += 1;
        }
    }
}
?>
