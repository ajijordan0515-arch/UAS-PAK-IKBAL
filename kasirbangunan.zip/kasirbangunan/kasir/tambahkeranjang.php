<?php
session_start();
include '../koneksi.php';

// Validasi input id_produk
if (!isset($_POST['id_produk'])) {
    echo "<script>alert('Produk tidak ditemukan'); window.location.href='produk.php';</script>";
    exit;
}

$id_produk = intval($_POST['id_produk']);

// Validasi session user
if (!isset($_SESSION['user']['id_toko'])) {
    echo "<script>alert('Sesi toko tidak ditemukan'); window.location.href='login.php';</script>";
    exit;
}

$id_toko = $_SESSION['user']['id_toko'];

// Ambil data produk berdasarkan toko & id_produk
$ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk' AND id_toko='$id_toko'");
$produk = $ambil->fetch_assoc();

// Validasi produk ditemukan dan stok masih ada
if ($produk && $produk['stok_produk'] > 0) {
    $stok = intval($produk['stok_produk']);
    $jumlah_sekarang = isset($_SESSION['keranjang'][$id_produk]) ? $_SESSION['keranjang'][$id_produk] : 0;

    if ($jumlah_sekarang < $stok) {
        $_SESSION['keranjang'][$id_produk] = $jumlah_sekarang + 1;
        echo "<script>alert('Produk ditambahkan ke keranjang'); window.location.href='produk.php';</script>";
    } else {
        echo "<script>alert('Stok produk tidak mencukupi'); window.location.href='produk.php';</script>";
    }
} else {
    echo "<script>alert('Produk tidak ditemukan atau stok habis'); window.location.href='produk.php';</script>";
}
?>
